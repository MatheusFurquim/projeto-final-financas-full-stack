package br.com.matheus.financas.domain.model;

public enum CategoriaPerfilRisco {

    CONSERVADOR,
    MODERADO,
    ARROJADO;

}
