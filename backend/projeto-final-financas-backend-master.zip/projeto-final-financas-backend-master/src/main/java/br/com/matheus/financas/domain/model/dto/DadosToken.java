package br.com.matheus.financas.domain.model.dto;

public record DadosToken(String token) {}
